var indexSectionsWithContent =
{
  0: "cdst",
  1: "t",
  2: "cd",
  3: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables"
};

